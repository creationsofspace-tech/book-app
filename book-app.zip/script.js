const defaultBooks = [
  [{ text: "Welcome to your book 📖" }, { text: "Edit this ✍️" }]
];

let currentUser = null;
let books = [];
let currentPage = 0;
let pages = [];

function signup() {
  const user = username.value;
  const pass = password.value;
  let users = JSON.parse(localStorage.getItem("users")) || {};

  if (users[user]) return alert("User exists");

  users[user] = { password: pass, books: defaultBooks };
  localStorage.setItem("users", JSON.stringify(users));
  alert("Created!");
}

function login() {
  const user = username.value;
  const pass = password.value;
  let users = JSON.parse(localStorage.getItem("users")) || {};

  if (!users[user] || users[user].password !== pass)
    return alert("Invalid");

  currentUser = user;
  books = users[user].books;

  document.getElementById("auth").style.display = "none";
  document.getElementById("app").style.display = "block";

  loadBook(0);
}

function loadBook(index) {
  const book = document.getElementById("book");
  book.innerHTML = "";
  pages = [];

  books[index].forEach((p, i) => {
    let page = document.createElement("div");
    page.className = "page";
    page.innerText = p.text;
    page.contentEditable = true;

    page.addEventListener("input", () => {
      books[index][i].text = page.innerText;
      saveData();
    });

    book.appendChild(page);
    pages.push(page);
  });
}

function saveData() {
  let users = JSON.parse(localStorage.getItem("users")) || {};
  users[currentUser].books = books;
  localStorage.setItem("users", JSON.stringify(users));
}

function nextPage() {
  if (currentPage < pages.length) {
    pages[currentPage].classList.add("flipped");
    currentPage++;
  }
}

function prevPage() {
  if (currentPage > 0) {
    currentPage--;
    pages[currentPage].classList.remove("flipped");
  }
}

function toggleTheme() {
  document.body.classList.toggle("dark");
  document.body.classList.toggle("light");
}
